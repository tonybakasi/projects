package controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.stage.FileChooser;
import model.Course;
import model.Delivery;
import model.Module;
import model.StudentProfile;
import view.ModuleSelectionRootPane;
import view.OverviewSelectionPane;
import view.ReserveModulePane;
import view.SelectModulePane;
import view.CreateProfilePane;
import view.ModuleSelectionMenuBar;

public class ModuleSelectionController {

	//fields to be used throughout class
	private StudentProfile model;
	private ModuleSelectionRootPane view;
	
	private CreateProfilePane cpp;
	private SelectModulePane smp;
	private ReserveModulePane rmp;
	private OverviewSelectionPane osp;
	private ModuleSelectionMenuBar msmb;
	public int reservedTerm1Credits;
	public int reservedTerm2Credits;

	public ModuleSelectionController(StudentProfile model, ModuleSelectionRootPane view) {
		//initialise model and view fields
	    this.model = model;
		this.view = view;
		
		//initialise view subcontainer fields
		cpp = view.getCreateProfilePane();
		smp = view.getSelectModulePane();
		rmp = view.getReserveModulePane();
		osp = view.getOverviewSelectionPane();
		msmb = view.getModuleSelectionMenuBar();

		//populate combobox in create profile pane with courses using the setupAndGetCourses method below
		cpp.populateCourseComboBox(setupAndGetCourses());

		//attach event handlers to view using private helper method
		this.attachEventHandlers();	
	}

	
	//a helper method used to attach event handlers
	private void attachEventHandlers() {
		//attach an event handler to the create profile pane
		cpp.addCreateProfileHandler(new CreateProfileHandler());
		
		//attach an event handler to the select module pane
		smp.addTerm1AddHandler(new AddTerm1Handler());
		smp.addTerm2AddHandler(new AddTerm2Handler());
		smp.addTerm1RemoveHandler(new RemoveTerm1Handler());
		smp.addTerm2RemoveHandler(new RemoveTerm2Handler());
		smp.addResetHandler(new ResetHandler());
		smp.addSubmitHandler(new SubmitHandler());
		
		//attach an event handler to the reserved module pane
		rmp.addTerm1AddHandler(new ReservedAddTerm1Handler());
		rmp.addTerm1RemoveHandler(new ReservedRemoveTerm1Handler());
		rmp.addTerm1ConfirmHandler(new ReservedConfirmTerm1Handler());
		
		rmp.addTerm2AddHandler(new ReservedAddTerm2Handler());
		rmp.addTerm2RemoveHandler(new ReservedRemoveTerm2Handler());
		rmp.addTerm2ConfirmHandler(new ReservedConfirmTerm2Handler());
		
		//attach an event handler to the overview pane
		osp.addSaveOverviewHandler(new SaveOverviewHandler());
		
		//attach an event handler to the menu bar that closes the application
		msmb.addSaveHandler(e -> {

            FileChooser fileChooser = new FileChooser();

            //Set extension filter for text files
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Module Selection Data File (*.mst)", "*.mst");
            fileChooser.getExtensionFilters().add(extFilter);

            //Show save file dialog
            File file = fileChooser.showSaveDialog(view.getStage());

            if (file != null) {
                try {
                    model.serialize(file.getAbsolutePath(), model);
                } catch (IOException ex) {
                    Logger.getLogger(ModuleSelectionController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
		});
		msmb.addLoadHandler(e -> {
            FileChooser fileChooser = new FileChooser();

            //Set extension filter for text files
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Module Selection Data File (*.mst)", "*.mst");
            fileChooser.getExtensionFilters().add(extFilter);

            File file = fileChooser.showOpenDialog(view.getStage());

            if (file != null) {
                try {
                    model = (StudentProfile) model.deSerialize(file.getAbsolutePath());
                    
                    //Create Profile Panel
                    cpp.getCboCourse().getSelectionModel().select(model.getCourse());
                    cpp.getTxtPnumber().setText(model.getpNumber());
                    cpp.getTxtFirstName().setText(model.getStudentName().getFirstName());
                    cpp.getTxtSurname().setText(model.getStudentName().getFamilyName());
                    cpp.getTxtEmail().setText(model.getEmail());
                    cpp.getInputDate().setValue(model.getSubmissionDate());
                    
                    //Select Module Panel
                    setupSelectModules(true);
            		
                    //Reserved Module Panel
        			resetReservedModule();
        			
            		Iterator<Module> reservedModules = model.getAllReservedModules().iterator();
            		
            		while(reservedModules.hasNext()) {
            			Module module = reservedModules.next();
            			
            			if(module.getRunPlan() == Delivery.TERM_1) {
                			rmp.getReservedTerm1Listview().getItems().add(module);
                			rmp.getUnselectedTerm1Listview().getItems().remove(module);
            			}

            			if(module.getRunPlan() == Delivery.TERM_2){
            				rmp.getReservedTerm2Listview().getItems().add(module);
            				rmp.getUnselectedTerm2Listview().getItems().remove(module);
            			}
            		}
            		
        			rmp.getPane2().setCollapsible(true);
        			rmp.getPane2().setExpanded(true);
        			
            		setupOverviewPane();
            		
                } catch (IOException ex) {
                	ex.printStackTrace();
                } catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            }
		});
		msmb.addAboutHandler(e -> {
            Dialog dialog = new Dialog();
            dialog.setWidth(400);
            dialog.getDialogPane().setMinWidth(400);
            dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
            dialog.getDialogPane().setContentText("A Module Selection Tool for Students");
            dialog.showAndWait();
		});
		msmb.addExitHandler(e -> System.exit(0));
	}
	
	//empty event handler, which can be used for creating a profile
	private class CreateProfileHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			model.setCourse(cpp.getSelectedCourse());
			model.setStudentName(cpp.getName());
			model.setpNumber(cpp.getPnumberInput());
			model.setEmail(cpp.getEmail());
			model.setSubmissionDate(cpp.getDate());
			
			setupSelectModules(false);
			view.changeTab(1);
		}
	}
	
	
	
	private class AddTerm1Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			Module module = smp.getUnselectedTerm1Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				int term1Credits = Integer.parseInt(smp.getTerm1Credit().getText());
				if(term1Credits < 60) {
					smp.getUnselectedTerm1Listview().getItems().remove(module);
					smp.getSelectedTerm1Listview().getItems().add(module);
				
					term1Credits += module.getCredits();
					smp.getTerm1Credit().setText(String.valueOf(term1Credits));
				}
			}
		}
	}
	
	private class AddTerm2Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {

			Module module = smp.getUnselectedTerm2Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				int term2Credits = Integer.parseInt(smp.getTerm2Credit().getText());
				if(term2Credits < 60) {
					smp.getUnselectedTerm2Listview().getItems().remove(module);
					smp.getSelectedTerm2Listview().getItems().add(module);
				
					term2Credits += module.getCredits();
					smp.getTerm2Credit().setText(String.valueOf(term2Credits));
				}
			}
		}
	}
	
	private class RemoveTerm1Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {

			Module module = smp.getSelectedTerm1Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				smp.getUnselectedTerm1Listview().getItems().add(module);
				smp.getSelectedTerm1Listview().getItems().remove(module);
				
				int term1Credits = Integer.parseInt(smp.getTerm1Credit().getText()) - module.getCredits();
				smp.getTerm1Credit().setText(String.valueOf(term1Credits));
			}
		}
	}
	
	private class RemoveTerm2Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			Module module = smp.getSelectedTerm2Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				smp.getUnselectedTerm2Listview().getItems().add(module);
				smp.getSelectedTerm2Listview().getItems().remove(module);
				
				
				int term2Credits = Integer.parseInt(smp.getTerm2Credit().getText()) - module.getCredits();
				smp.getTerm2Credit().setText(String.valueOf(term2Credits));
			}
		}
	}
	
	private class ResetHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			setupSelectModules(false);
		}
	}
	
	private class SubmitHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			model.clearReservedModules();
			model.clearSelectedModules();
			
			resetReservedModule();
			
			ObservableList<Module> selectedTerm1List = smp.getSelectedTerm1Listview().getItems();
			Iterator<Module> selectedTerm1Modules = selectedTerm1List.iterator();
			while(selectedTerm1Modules.hasNext()) {
				Module module = selectedTerm1Modules.next();
				model.addSelectedModule(module);
			}
			
			ObservableList<Module> selectedTerm2List = smp.getSelectedTerm2Listview().getItems();
			Iterator<Module> selectedTerm2Modules = selectedTerm2List.iterator();
			while(selectedTerm2Modules.hasNext()) {
				Module module = selectedTerm2Modules.next();
				model.addSelectedModule(module);
			}
			
			view.changeTab(2);
		}
	}
	
	private class ReservedAddTerm1Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {

			Module module = rmp.getUnselectedTerm1Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				reservedTerm1Credits += module.getCredits();
				if(reservedTerm1Credits <= 30) {
					rmp.getUnselectedTerm1Listview().getItems().remove(module);
					rmp.getReservedTerm1Listview().getItems().add(module);
				}else {
					reservedTerm1Credits -= module.getCredits();
				}
			}
		}
	}

	private class ReservedRemoveTerm1Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			Module module = rmp.getReservedTerm1Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				reservedTerm1Credits -= module.getCredits();
				rmp.getUnselectedTerm1Listview().getItems().add(module);
				rmp.getReservedTerm1Listview().getItems().remove(module);
			}
		}
	}
	
	private class ReservedConfirmTerm1Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			ObservableList<Module> list = rmp.getReservedTerm1Listview().getItems();
			rmp.getPane2().setCollapsible(true);
			rmp.getPane2().setExpanded(true);
			
			Iterator<Module> modules = list.iterator();
			
			while(modules.hasNext()) {
				Module module = modules.next();
				model.addReservedModule(module);
			}
		}
	}
	
	private class ReservedAddTerm2Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			Module module = rmp.getUnselectedTerm2Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				reservedTerm2Credits += module.getCredits();
				if(reservedTerm2Credits <= 30) {
					rmp.getUnselectedTerm2Listview().getItems().remove(module);
					rmp.getReservedTerm2Listview().getItems().add(module);
				}else {
					reservedTerm2Credits -= module.getCredits();
				}
			}
		}
	}

	private class ReservedRemoveTerm2Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			Module module = rmp.getReservedTerm2Listview().getSelectionModel().getSelectedItem();
			if(module != null) {
				reservedTerm2Credits -= module.getCredits();
				rmp.getUnselectedTerm2Listview().getItems().add(module);
				rmp.getReservedTerm2Listview().getItems().remove(module);
			}
		}
	}
	
	private class ReservedConfirmTerm2Handler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			ObservableList<Module> list = rmp.getReservedTerm2Listview().getItems();
			Iterator<Module> modules = list.iterator();
			while(modules.hasNext()) {
				Module module = modules.next();
				model.addReservedModule(module);
			}

			setupOverviewPane();
			
			view.changeTab(3);
		}
	}
	
	private class SaveOverviewHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
            FileChooser fileChooser = new FileChooser();
            
            //Set extension filter for text files
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
            fileChooser.getExtensionFilters().add(extFilter);
 
            //Show save file dialog
            File file = fileChooser.showSaveDialog(view.getStage());
 
            if (file != null) {
            	writeOverviewToFile(file);
            }
		}
	}


	//generates all module and course data and returns courses within an array
	private Course[] setupAndGetCourses() {
		Module imat3423 = new Module("IMAT3423", "Systems Building: Methods", 15, true, Delivery.TERM_1);
		Module ctec3451 = new Module("CTEC3451", "Development Project", 30, true, Delivery.YEAR_LONG);
		Module ctec3902_SoftEng = new Module("CTEC3902", "Rigorous Systems", 15, true, Delivery.TERM_2);	
		Module ctec3902_CompSci = new Module("CTEC3902", "Rigorous Systems", 15, false, Delivery.TERM_2);
		Module ctec3110 = new Module("CTEC3110", "Secure Web Application Development", 15, false, Delivery.TERM_1);
		Module ctec3605 = new Module("CTEC3605", "Multi-service Networks 1", 15, false, Delivery.TERM_1);	
		Module ctec3606 = new Module("CTEC3606", "Multi-service Networks 2", 15, false, Delivery.TERM_2);	
		Module ctec3410 = new Module("CTEC3410", "Web Application Penetration Testing", 15, false, Delivery.TERM_2);
		Module ctec3904 = new Module("CTEC3904", "Functional Software Development", 15, false, Delivery.TERM_2);
		Module ctec3905 = new Module("CTEC3905", "Front-End Web Development", 15, false, Delivery.TERM_2);
		Module ctec3906 = new Module("CTEC3906", "Interaction Design", 15, false, Delivery.TERM_1);
		Module imat3410 = new Module("IMAT3104", "Database Management and Programming", 15, false, Delivery.TERM_2);
		Module imat3406 = new Module("IMAT3406", "Fuzzy Logic and Knowledge Based Systems", 15, false, Delivery.TERM_1);
		Module imat3611 = new Module("IMAT3611", "Computer Ethics and Privacy", 15, false, Delivery.TERM_1);
		Module imat3613 = new Module("IMAT3613", "Data Mining", 15, false, Delivery.TERM_1);
		Module imat3614 = new Module("IMAT3614", "Big Data and Business Models", 15, false, Delivery.TERM_2);
		Module imat3428_CompSci = new Module("IMAT3428", "Information Technology Services Practice", 15, false, Delivery.TERM_2);


		Course compSci = new Course("Computer Science");
		compSci.addModule(imat3423);
		compSci.addModule(ctec3451);
		compSci.addModule(ctec3902_CompSci);
		compSci.addModule(ctec3110);
		compSci.addModule(ctec3605);
		compSci.addModule(ctec3606);
		compSci.addModule(ctec3410);
		compSci.addModule(ctec3904);
		compSci.addModule(ctec3905);
		compSci.addModule(ctec3906);
		compSci.addModule(imat3410);
		compSci.addModule(imat3406);
		compSci.addModule(imat3611);
		compSci.addModule(imat3613);
		compSci.addModule(imat3614);
		compSci.addModule(imat3428_CompSci);

		Course softEng = new Course("Software Engineering");
		softEng.addModule(imat3423);
		softEng.addModule(ctec3451);
		softEng.addModule(ctec3902_SoftEng);
		softEng.addModule(ctec3110);
		softEng.addModule(ctec3605);
		softEng.addModule(ctec3606);
		softEng.addModule(ctec3410);
		softEng.addModule(ctec3904);
		softEng.addModule(ctec3905);
		softEng.addModule(ctec3906);
		softEng.addModule(imat3410);
		softEng.addModule(imat3406);
		softEng.addModule(imat3611);
		softEng.addModule(imat3613);
		softEng.addModule(imat3614);

		Course[] courses = new Course[2];
		courses[0] = compSci;
		courses[1] = softEng;

		return courses;
	}
	
	private void clearForm() {
	    if (smp.getUnselectedTerm1Listview().getItems().size() != 0) 
	    	smp.getUnselectedTerm1Listview().getItems().clear();
	    if (smp.getUnselectedTerm2Listview().getItems().size() != 0) 
	    	smp.getUnselectedTerm2Listview().getItems().clear();
	    if (smp.getSelectedTerm1Listview().getItems().size() != 0) 
	    	smp.getSelectedTerm1Listview().getItems().clear();
	    if (smp.getSelectedTerm2Listview().getItems().size() != 0) 
	    	smp.getSelectedTerm2Listview().getItems().clear();
	    if (smp.getSelectedYearLongListview().getItems().size() != 0) 
	    	smp.getSelectedYearLongListview().getItems().clear();
	    
	    if (rmp.getUnselectedTerm1Listview().getItems().size() != 0) 
	    	rmp.getUnselectedTerm1Listview().getItems().clear();
	    if (rmp.getUnselectedTerm2Listview().getItems().size() != 0) 
	    	rmp.getUnselectedTerm2Listview().getItems().clear();
	    if (rmp.getReservedTerm1Listview().getItems().size() != 0) 
	    	rmp.getReservedTerm1Listview().getItems().clear();
	    if (rmp.getReservedTerm2Listview().getItems().size() != 0) 
	    	rmp.getReservedTerm2Listview().getItems().clear();
	    
	    osp.getStudentProfileTextArea().clear();
	    osp.getSelectedModuleTextArea().clear();
	    osp.getReservedModuleTextArea().clear();
	}
	
	public void writeOverviewToFile(File file) {
	        try {
	            PrintWriter writer;
	            writer = new PrintWriter(file);

	            writer.println(osp.getStudentProfileTextArea().getText());
	            writer.println("\n");
	            writer.println(osp.getSelectedModuleTextArea().getText());
	            writer.println("\n");
	            writer.println(osp.getReservedModuleTextArea().getText());
	            writer.close();
	        } catch (IOException ex) {
	            Logger.getLogger(ModuleSelectionController.class.getName()).log(Level.SEVERE, null, ex);
	        }
	}
	
	private void setupSelectModules(boolean deserialized) {
		if(!deserialized) {
			model.clearReservedModules();
			model.clearSelectedModules();
		}

		clearForm();
		
		Iterator<Module> modules = model.getCourse().getAllModulesOnCourse().iterator();

		
		int term1Credits = 0, term2Credits = 0;
		
		while(modules.hasNext()) {
			Module module = modules.next();
			
			if(module.getRunPlan() == Delivery.TERM_1) {
				if(module.isMandatory()) {
					smp.populateSelectedTerm1Modules(module);
					term1Credits += module.getCredits();
				}else {
					smp.populateUnselectedTerm1Modules(module);
				}
			}

			if(module.getRunPlan() == Delivery.TERM_2){
				if(module.isMandatory()) {
					smp.populateSelectedTerm2Modules(module);
					term2Credits += module.getCredits();
				}else {
					smp.populateUnselectedTerm2Modules(module);
				}
			}

			if(module.getRunPlan() == Delivery.YEAR_LONG) {
				smp.populateYearLongModules(module);
			}
			
		}
		
		if(deserialized) {

    		Iterator<Module> selectedModules = model.getAllSelectedModules().iterator();
    		
    		term1Credits = term2Credits = 0;
    		
    		while(selectedModules.hasNext()) {
    			Module module = selectedModules.next();
    			
    			if(module.getRunPlan() == Delivery.TERM_1) {
    				if(!module.isMandatory()) {
        				smp.populateSelectedTerm1Modules(module);
        				smp.getUnselectedTerm1Listview().getItems().remove(module);
    				}

    				term1Credits += module.getCredits();
    			}

    			if(module.getRunPlan() == Delivery.TERM_2){
    				if(!module.isMandatory()) {
        				smp.populateSelectedTerm2Modules(module);
        				smp.getUnselectedTerm2Listview().getItems().remove(module);
    				}
    				term2Credits += module.getCredits();
    			}
    		}
		}
		
		smp.getSelectedYearLongListview().getSelectionModel().selectFirst();
		int yearLongCredits = smp.getSelectedYearLongListview().getSelectionModel().getSelectedItem().getCredits() / 2;
		
		smp.getTerm1Credit().setText(String.valueOf(term1Credits + yearLongCredits));
		smp.getTerm2Credit().setText(String.valueOf(term2Credits + yearLongCredits));
	}
	
	private void setupOverviewPane() {
		osp.getStudentProfileTextArea().setText(
				"Name: " + model.getStudentName().getFullName() +
				"\nPNo: " + model.getpNumber() + 
				"\nEmail: " + model.getEmail() + 
				"\nDate: " + model.getSubmissionDate()+ 
				"\nCourse: " + model.getCourse()
		);
		
		String selectedModuleRes = "Selected modules:\n==========";
		Iterator<Module> selectedModulesIterator = model.getAllSelectedModules().iterator();
		while(selectedModulesIterator.hasNext()) {
			Module module = selectedModulesIterator.next();
			selectedModuleRes +=
					"\nModule code: " + module.getModuleCode() + 
					" Module name: " + module.getModuleName() + 
					"\nCredits: " + module.getCredits() + 
					" Mandatory on your course? " + (module.isMandatory()?"yes":"no") + 
					" Delivery: " + module.getRunPlan();
		}
		osp.getSelectedModuleTextArea().setText(selectedModuleRes);
		
		String reservedModuleRes = "Reserved modules:\n==========";
		Iterator<Module> reservedModulesIterator = model.getAllReservedModules().iterator();
		while(reservedModulesIterator.hasNext()) {
			Module module = reservedModulesIterator.next();
			reservedModuleRes += 
					"\nModule code: " + module.getModuleCode() + 
					" Module name: " + module.getModuleName() + 
					"\nCredits: " + module.getCredits() + 
					" Mandatory on your course? " + (module.isMandatory()?"yes":"no") + 
					" Delivery: " + module.getRunPlan();
		}
		osp.getReservedModuleTextArea().setText(reservedModuleRes);
	}

	private void resetReservedModule() {
		ObservableList<Module> unselectedTerm1List = smp.getUnselectedTerm1Listview().getItems();
		rmp.getUnselectedTerm1Listview().getItems().clear();
		rmp.getUnselectedTerm1Listview().getItems().addAll(unselectedTerm1List);
		
		ObservableList<Module> unselectedTerm2List = smp.getUnselectedTerm2Listview().getItems();
		rmp.getUnselectedTerm2Listview().getItems().clear();
		rmp.getUnselectedTerm2Listview().getItems().addAll(unselectedTerm2List);
		
		rmp.getReservedTerm1Listview().getItems().clear();
		rmp.getReservedTerm2Listview().getItems().clear();
	}
}
