package view;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;

public class OverviewSelectionPane extends GridPane {

	private TextArea studentProfileTextArea,selectedModuleTextArea,reservedModuleTextArea;
	private Button saveBtn;
	
	public OverviewSelectionPane() {
		
				this.setVgap(15);
				this.setHgap(20);
				this.setPadding(new Insets(20));
				this.setAlignment(Pos.CENTER);
				
				ColumnConstraints column0 = new ColumnConstraints();
				column0.setHalignment(HPos.CENTER);

				this.getColumnConstraints().addAll(column0);
				
				//setup TextArea
				studentProfileTextArea = new TextArea("Profile will appear here");
				selectedModuleTextArea = new TextArea("Selected modules will appear here");
				reservedModuleTextArea = new TextArea("Reserved modules will appear here");
				
				saveBtn = new Button("Save Overview");
				saveBtn.setAlignment(Pos.CENTER);
				
				//add controls and labels to container
				this.add(studentProfileTextArea, 0, 0, 2,1);
				this.add(selectedModuleTextArea, 0, 1);
				this.add(reservedModuleTextArea, 1, 1);
				this.add(saveBtn, 0, 2, 2,1);
				
				ChangeListener<Number> updater = (o, oV, nV) ->
				{
				    double newWidth = this.getWidth();
				    double newHeight = this.getHeight();

				    studentProfileTextArea.setPrefSize(newWidth, newHeight);
				    selectedModuleTextArea.setPrefSize(newWidth, newHeight);
				    reservedModuleTextArea.setPrefSize(newWidth, newHeight);
				};
				this.widthProperty().addListener(updater);
				this.heightProperty().addListener(updater);
				
				this.setPrefSize(784, 507);
	}
	
	public void addSaveOverviewHandler(EventHandler<ActionEvent> handler) {
		saveBtn.setOnAction(handler);
	}
	
	public TextArea getStudentProfileTextArea() {
		return studentProfileTextArea;
	}

	public TextArea getSelectedModuleTextArea() {
		return selectedModuleTextArea;
	}

	public TextArea getReservedModuleTextArea() {
		return reservedModuleTextArea;
	}
	

}
