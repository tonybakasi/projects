package view;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Module;

public class SelectModulePane extends GridPane {

	private ListView<Module> unselectedTerm1Listview,unselectedTerm2Listview,selectedTerm1Listview,selectedTerm2Listview,selectedYearLongListview;
	private Button btnAddTerm1,btnAddTerm2,btnRemoveTerm1,btnRemoveTerm2,btnReset,btnSubmit;
	private TextField txtTerm1Credit, txtTerm2Credit;
	
	public SelectModulePane() {
		
		this.setVgap(15);
		this.setHgap(20);
		this.setPadding(new Insets(20));
		this.setAlignment(Pos.CENTER);
		
		//create labels
		Label lblUnselectedTerm1 = new Label("Unselected Term 1 modules");
		Label lblUnselectedTerm2 = new Label("Unselected Term2 modules");
		Label lblSelectedTerm1 = new Label("Selected Term 1 modules");
		Label lblSelectedTerm2 = new Label("Selected Term 2 modules");
		Label lblSelectedYearLong = new Label("Selected Year Long modules");
		Label lblTerm1 = new Label("Term 1");
		lblTerm1.setPadding(new Insets(10));
		Label lblTerm2 = new Label("Term 2");
		lblTerm2.setPadding(new Insets(10));
		Label lblTerm1Credits = new Label("Current term 1 credits:");
		lblTerm1Credits.setPadding(new Insets(10));
		Label lblTerm2Credits = new Label("Current term 2 credits:");
		lblTerm2Credits.setPadding(new Insets(10,10,10,100));
		
		//setup lisviews
		unselectedTerm1Listview = new ListView<>();
//		unselectedTerm1Listview.setMinHeight(100);
		unselectedTerm2Listview = new ListView<>();
//		unselectedTerm2Listview.setMinHeight(100);
		selectedTerm1Listview = new ListView<>();
//		selectedTerm1Listview.setMinHeight(100);
		selectedTerm2Listview = new ListView<>();
//		selectedTerm2Listview.setMinHeight(100);
		selectedYearLongListview = new ListView<>();
//		selectedYearLongListview.setMinHeight(50);
		
		//setup text fields
		txtTerm1Credit = new TextField();
		txtTerm1Credit.setPrefSize(50, 30);
		
		txtTerm2Credit = new TextField();
		txtTerm2Credit.setPrefSize(50, 30);
		
		//setup buttons
		btnAddTerm1 = new Button("Add");
		btnAddTerm2 = new Button("Add");
		btnRemoveTerm1 = new Button("Remove");
		btnRemoveTerm2 = new Button("Remove");
		btnReset = new Button("Reset");
		btnSubmit = new Button("Submit");
		
		VBox unselectedTerm1 = new VBox(lblUnselectedTerm1, unselectedTerm1Listview);

		
		HBox unselectedTerm1Btn = new HBox(lblTerm1, btnAddTerm1, btnRemoveTerm1);
		unselectedTerm1Btn.setAlignment(Pos.CENTER);
		unselectedTerm1Btn.setSpacing(15);
		
		VBox unselectedTerm2 = new VBox(lblUnselectedTerm2, unselectedTerm2Listview);
		HBox unselectedTerm2Btn = new HBox(lblTerm2, btnAddTerm2, btnRemoveTerm2);
		unselectedTerm2Btn.setAlignment(Pos.CENTER);
		unselectedTerm2Btn.setSpacing(15);
		
		VBox combinedUnselected = new VBox(unselectedTerm1Btn, unselectedTerm2, unselectedTerm2Btn);
		combinedUnselected.setAlignment(Pos.CENTER);

		//add controls and labels to container
		this.add(unselectedTerm1, 0, 0);
//		this.add(unselectedTerm1Btn, 0, 1);
//		this.add(unselectedTerm2, 0, 2);
//		this.add(unselectedTerm2Btn, 0, 3);
		this.add(combinedUnselected, 0, 1, 1,2);
		
		VBox selectedYearLong = new VBox(lblSelectedYearLong, selectedYearLongListview);
		selectedYearLong.setMaxHeight(50);
		VBox selectedTerm1 = new  VBox(lblSelectedTerm1, selectedTerm1Listview);
		VBox selectedTerm2 = new VBox(lblSelectedTerm2, selectedTerm2Listview);
		
		this.add(selectedYearLong, 1, 0);
		this.add(selectedTerm1, 1, 1);
		this.add(selectedTerm2, 1, 2);

		HBox txtFields = new HBox(lblTerm1Credits, txtTerm1Credit,lblTerm2Credits, txtTerm2Credit);
		txtFields.setAlignment(Pos.CENTER);
		this.add(txtFields, 0, 4, 2,1);
		
		HBox resetSubmitBtn = new HBox(btnReset, btnSubmit);
		resetSubmitBtn.setAlignment(Pos.CENTER);
		resetSubmitBtn.setSpacing(30);
		this.add(resetSubmitBtn, 0, 5,2,1);
			
		
		int rowCount = 3, columnCount = 2; // You should know these values.
		ChangeListener<Number> updater = (o, oV, nV) ->
		{
		    double newWidth = this.getWidth() / columnCount;
		    double newHeight = this.getHeight() / rowCount;
		    this.getChildren().forEach(n ->
		    {
		    	unselectedTerm1.setPrefSize(newWidth, newHeight);
		    	unselectedTerm2.setPrefSize(newWidth, newHeight);
		    	selectedTerm1.setPrefSize(newWidth, newHeight);
		    	selectedTerm2.setPrefSize(newWidth, newHeight);
		    });
		};
		this.widthProperty().addListener(updater);
		this.heightProperty().addListener(updater);
		
		this.setPrefSize(784, 507);
	}
	
	public void populateUnselectedTerm1Modules(Module module) {
		getUnselectedTerm1Listview().getItems().addAll(module);
	}
	
	public void populateUnselectedTerm2Modules(Module module) {
		unselectedTerm2Listview.getItems().addAll(module);
	}

	public void populateSelectedTerm1Modules(Module module) {
		selectedTerm1Listview.getItems().addAll(module);
	}
	
	public void populateSelectedTerm2Modules(Module module) {
		selectedTerm2Listview.getItems().addAll(module);
	}
	
	public void populateYearLongModules(Module module) {
		selectedYearLongListview.getItems().addAll(module);
	}
		
	public TextField getTerm1Credit() {
		return txtTerm1Credit;
	}
	
	
	public TextField getTerm2Credit() {
		return txtTerm2Credit;
	}
	
	public void addTerm1AddHandler(EventHandler<ActionEvent> handler) {
		btnAddTerm1.setOnAction(handler);
	}
	
	public void addTerm2AddHandler(EventHandler<ActionEvent> handler) {
		btnAddTerm2.setOnAction(handler);
	}
	
	public void addTerm1RemoveHandler(EventHandler<ActionEvent> handler) {
		btnRemoveTerm1.setOnAction(handler);
	}
	
	public void addTerm2RemoveHandler(EventHandler<ActionEvent> handler) {
		btnRemoveTerm2.setOnAction(handler);
	}
	
	public void addResetHandler(EventHandler<ActionEvent> handler) {
		btnReset.setOnAction(handler);
	}
	
	public void addSubmitHandler(EventHandler<ActionEvent> handler) {
		btnSubmit.setOnAction(handler); 
	}

	public ListView<Module> getUnselectedTerm1Listview() {
		return unselectedTerm1Listview;
	}
	public ListView<Module> getUnselectedTerm2Listview() {
		return unselectedTerm2Listview;
	}
	public ListView<Module> getSelectedTerm1Listview() {
		return selectedTerm1Listview;
	}
	public ListView<Module> getSelectedTerm2Listview() {
		return selectedTerm2Listview;
	}
	public ListView<Module> getSelectedYearLongListview() {
		return selectedYearLongListview;
	}

}
