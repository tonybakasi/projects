package view;

import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Module;

public class ReserveModulePane extends VBox {

	private ListView<Module> unselectedTerm1Listview,unselectedTerm2Listview,reservedTerm1Listview,reservedTerm2Listview;
	private Button btnAddTerm1,btnAddTerm2,btnRemoveTerm1,btnRemoveTerm2,btnConfirmTerm1,btnConfirmTerm2;
	private TitledPane pane1;
	private TitledPane pane2;

	public ReserveModulePane() {
	
//				this.setVgap(15);
//				this.setHgap(20);
				this.setPadding(new Insets(20));
				this.setAlignment(Pos.TOP_CENTER);
				
				//create labels
				Label lblUnselectedTerm1 = new Label("Unselected Term 1 modules");
				Label lblUnselectedTerm2 = new Label("Unselected Term2 modules");
				Label lblReservedTerm1 = new Label("Reserved Term 1 modules");
				Label lblReservedTerm2 = new Label("Reserved Term 2 modules");
				Label lblCreditsTerm1 = new Label("Reserved 30 credits worth of term 1 modules");
				Label lblCreditsTerm2 = new Label("Reserved 30 credits worth of term 2 modules");
				
				//setup lisviews
				unselectedTerm1Listview = new ListView<>();
				unselectedTerm2Listview = new ListView<>();
				reservedTerm1Listview = new ListView<>();
				reservedTerm2Listview = new ListView<>();
				
				
				//setup buttons
				btnAddTerm1 = new Button("Add");
				btnAddTerm2 = new Button("Add");
				btnRemoveTerm1 = new Button("Remove");
				btnRemoveTerm2 = new Button("Remove");
				btnConfirmTerm1 = new Button("Confirm");
				btnConfirmTerm2 = new Button("Confirm");
				
				VBox term1Unselected = new VBox(lblUnselectedTerm1, unselectedTerm1Listview);
				VBox term1Reserved = new VBox(lblReservedTerm1, reservedTerm1Listview);
				
				HBox term1Box = new HBox(term1Unselected,term1Reserved);
				term1Box.setSpacing(20);
				
				VBox term2Unselected = new VBox(lblUnselectedTerm2, unselectedTerm2Listview);
				VBox term2Reserved = new VBox(lblReservedTerm2, reservedTerm2Listview);
				
				HBox term2Box = new HBox(term2Unselected,term2Reserved);
				term2Box.setSpacing(20);
				
		        Accordion accordion = new Accordion();
		     
		        HBox lblBtnTerm1 = new HBox(lblCreditsTerm1, btnAddTerm1,btnRemoveTerm1, btnConfirmTerm1);
		        lblBtnTerm1.setSpacing(20);
		        lblBtnTerm1.setPadding(new Insets(20));
		        lblBtnTerm1.setAlignment(Pos.CENTER);
		        
		        VBox term1Modules = new VBox(term1Box, lblBtnTerm1); 
		        term1Modules.setPadding(new Insets(20));
		        
		        
		        pane1 = new TitledPane("Term 1 modules" , term1Modules);
		        
		        HBox lblBtnTerm2 = new HBox(lblCreditsTerm2, btnAddTerm2,btnRemoveTerm2, btnConfirmTerm2);
		        lblBtnTerm2.setSpacing(20);
		        lblBtnTerm2.setPadding(new Insets(20));
		        lblBtnTerm2.setAlignment(Pos.CENTER);
		        
		        VBox term2Modules = new VBox(term2Box, lblBtnTerm2); 
		        
		        pane2 = new TitledPane("Term 2 modules"  , term2Modules);
		        pane2.setCollapsible(false);
		        
		        accordion.setExpandedPane(pane1);
		        accordion.getPanes().add(pane1);
		        accordion.getPanes().add(pane2);
		        
		        this.getChildren().add(accordion);
		        
				ChangeListener<Number> updater = (o, oV, nV) ->
				{
				    double newWidth = this.getWidth();
				    double newHeight = this.getHeight();

				    term1Unselected.setPrefSize(newWidth, newHeight);
				    term1Reserved.setPrefSize(newWidth, newHeight);
				    
				    term2Unselected.setPrefSize(newWidth, newHeight);
				    term2Reserved.setPrefSize(newWidth, newHeight);
				};
				this.widthProperty().addListener(updater);
				this.heightProperty().addListener(updater);
					
				this.setPrefSize(784, 507);
	}
	
	public TitledPane getPane2() {
		return pane2;
	}

	public ListView<Module> getUnselectedTerm1Listview() {
		return unselectedTerm1Listview;
	}

	public ListView<Module> getUnselectedTerm2Listview() {
		return unselectedTerm2Listview;
	}


	public ListView<Module> getReservedTerm1Listview() {
		return reservedTerm1Listview;
	}


	public ListView<Module> getReservedTerm2Listview() {
		return reservedTerm2Listview;
	}


	public void addTerm1AddHandler(EventHandler<ActionEvent> handler) {
		btnAddTerm1.setOnAction(handler);
	}
	
	public void addTerm1RemoveHandler(EventHandler<ActionEvent> handler) {
		btnRemoveTerm1.setOnAction(handler);
	}
	
	public void addTerm1ConfirmHandler(EventHandler<ActionEvent> handler) {
		btnConfirmTerm1.setOnAction(handler);
	}
	

	public void addTerm2AddHandler(EventHandler<ActionEvent> handler) {
		btnAddTerm2.setOnAction(handler);
	}
	
	public void addTerm2RemoveHandler(EventHandler<ActionEvent> handler) {
		btnRemoveTerm2.setOnAction(handler);
	}
	
	public void addTerm2ConfirmHandler(EventHandler<ActionEvent> handler) {
		btnConfirmTerm2.setOnAction(handler);
	}
}
