package com.example.maths4l1fev1;

import android.content.Context;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import dagger.hilt.android.lifecycle.HiltViewModel

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.inject.Inject

@HiltViewModel
class QuizActivityViewModel @Inject constructor(): ViewModel() {

    companion object {
        // initialize a static variable with maximum number of question to display.
        const val LAST_QUESTION_NUMBER = 14
    }

    // initializing an empty array list of questions.
    var mQuestionsList = mutableListOf<Question>()

    /*
     * This function will take context as input,
     * it will create a new object of QuizDbHelper
     * it will take all the question from QuizDbHelper and will store in a tmp list.
     * then it will shuffle that list.
     * then it will loop over max iteration of question required to be solved.
     * will add each question from each iteration to the member variable "mQuestionsList"
     * after that the member variable "mQuestionsList" will be having max question to be
     * displayed.
     * @param context
     */
    fun setQuestions(context: Context) {
        if (mQuestionsList.size < LAST_QUESTION_NUMBER) { // checking if mQuestionList array size is less than MaxNumberOfQuestionToDisplay
            val dbHelper = QuizDbHelper(context); // initializing quizDbHelper object
            val tmpQuestions = dbHelper.getAllQuestions().toMutableList(); // initializing a new list of questions, by getting questions from dbHelper class.
            tmpQuestions.shuffle(); // shuffling the list of questions.

            for (i in 0 until LAST_QUESTION_NUMBER) { // looping over the questions.
                mQuestionsList.add(tmpQuestions.get(i)); // adding question to mQuestionsList
            }
        }
    }

    val head = MutableLiveData(0); // creating a live data object of type head with an initial value of 0
    val currentQuestion = MutableLiveData<Question>() // creating a live data object of type Question with no initial value.

    /*
     * creating a live data object of type GameState with an initial value of GameState.IDLE
     * GameState type is an enum class, which is used for constant purposes.
     */
    val gameState = MutableLiveData(GameState.IDLE)

    /*
     * this function moves current question to nextQuestion.
     */
    fun moveToNextQuestion() {
        val head = this.head.value; // initializing a new head variable with the value from live data object 'head'
        if (head != null) { // checking if the value is not null
            if (head < LAST_QUESTION_NUMBER) { // if the head is less than LAST_QUESTION_NUMBER
                // setting the currentQuestion live data object value to new Question from list, via head index
                currentQuestion.setValue(mQuestionsList.get(head));
                this.head.setValue(head + 1); // incrementing the head index value. also setting that value of head live data object.
            } else { // if head index is greater than LAST_QUESTION_NUMBER,
                gameState.setValue(GameState.OVER); // then setting the game state to OVER.
            }
        }
    }

    enum class GameState { // Create Enum class for GameState
        IDLE, STARTED, OVER // defined three states for the GAME
    }

    val currentScore = MutableLiveData(0); // creating a live data object for currentScore with an initial value of 0

    /*
     * Following function checks the answer of question,
     * then increments the score if answer is correct,
     * and after that it calls the function 'moveToNextQuestion'
     * which moves the currentQuestion to NextQuestion.
     */
    fun checkAnswerAndUpdateScoreThenMoveNext(selectedOptionNumber: Int) {
        val currentQuestion = this.currentQuestion.value; // creating a new variable with a value of currentQuestion from live data object.
        if (currentQuestion != null) { // checking if currentQuestion object is not null.
            if (currentQuestion.getAnswrNr() == selectedOptionNumber) { // Correct Answer
                val previousScore = currentScore.value; // getting previous score.
                if (previousScore != null) { // checking if previous score object is not null.
                    currentScore.setValue(previousScore + 1); // Incrementing Score
                }
            }
        }
        moveToNextQuestion(); // moving towards next question
    }

    /*
     * returns gameOver message with the count of currentScore
     */
    fun getGameOverMsg(): String {
        val score = currentScore.value;
        if (score != null) {
            return "You Scored: " + score;
        }
        return "";
    }

    var oldHighScore = 0; // initializing a variable oldHighScore with the value of 0

    /*
     * this function fetches the current high score of a user from database.
     * and set that high score to the above declared oldHighScore variable.
     */
    fun setOldHighScore(context: Context, username: String) {
        val dbHelper = DBHelper(context); // instantiating a new object of dbHelper class.
        oldHighScore = Integer.parseInt(dbHelper.getScore(username)); // setting oldHighScore variable with the value from dbHelperClass.
    }

    /*
     * this function updates the new HighScore of user
     * if the newHighScore is greater than the previous high score.
     */
    fun setNewHighScoreInDB(context: Context, username: String) {
        val dbHelper = DBHelper(context); // instantiating a new object of dbHelper class.
        val newHighScore = currentScore.value; // creating a newHighScore Variable, with value of currentScore
        if (newHighScore != null) { // checking if newHighScore object is not null.
            if (newHighScore > oldHighScore) { // if newHighScore is greater than the oldHighScore
                dbHelper.updateScore(newHighScore.toString(), username); // updating the value of oldHighScore to newHighScore in database.
            }
        }
    }
}
