package com.example.maths4l1fev1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.maths4l1fev1.databinding.ActivityMainBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var mBinding: ActivityMainBinding
    private lateinit var mDBHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        mDBHelper = DBHelper(this)

        mBinding.btnsignup.setOnClickListener {
            val user = mBinding.username.text.toString()
            val pass = mBinding.password.text.toString()
            val repass = mBinding.repassword.text.toString()

            if(user == "" || pass == "" || repass == "")
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            else{
                if(pass == repass){
                    if(!mDBHelper.checkUsername(user)){
                        var insert = mDBHelper.insertData(user, pass);
                        if (insert) {
                            Toast.makeText(this, "Registration Complete", Toast.LENGTH_SHORT).show();
                            val intent = Intent(this, HomeActivity::class.java);
                            intent.putExtra("username", user); // sending username to HomeActivity along
                            startActivity(intent);
                        }else{
                            Toast.makeText(this, "Registration Failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                    else{
                        Toast.makeText(this, "User Already Exists! Sign in instead", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(this, "Passwords Do Not Match!", Toast.LENGTH_SHORT).show();
                }
            }
        }

        mBinding.btnsignin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

}