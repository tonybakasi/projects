package com.example.maths4l1fev1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

class DBHelper(val context: Context): SQLiteOpenHelper(context, DBNAME, null, 1) {

    companion object {
        const val DBNAME = "Login.db"
    }

    override fun onCreate(MyDB: SQLiteDatabase) {
        MyDB.execSQL("create Table users(username TEXT primary key, password TEXT, score TEXT)") // Add New Score Column for User
    }

    override fun onUpgrade(db: SQLiteDatabase, p1: Int, p2: Int) {
        db.execSQL("drop Table if exists users")
        onCreate(db)
    }

    fun insertData(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put("username", username)
        contentValues.put("password", password)
        contentValues.put("score", "0")  // Add Default 0 value for score column on user registration
        val result = db.insert("users", null, contentValues)
        return result != -1L
    }

    fun checkUsername(username: String): Boolean {
        val db = this.writableDatabase
        val cursor = db.rawQuery("Select * from users where username = ?", arrayOf(username))
        return cursor.count > 0
    }

    fun checkUsernamePassword(username: String, password: String): Boolean {
        val db = this.writableDatabase
        val cursor = db.rawQuery("Select * from users where  username  = ? and password = ?", arrayOf(username, password))
        return cursor.count > 0
    }

    /**
     * Create Function to get current score of this user
     * @param username
     * @return
     */
    fun getScore(username: String): String {
        val db = this.writableDatabase
        val cursor = db.rawQuery("Select * from users where username = ?", arrayOf(username))
        cursor.moveToNext()
        return cursor.getString(2)
    }

    /**
     * This function updates the high score of a user
     * @param score
     * @param username
     */
    fun updateScore(score: String, username: String) {
        val db = this.writableDatabase

        val values = ContentValues()
        values.put("score", score)

        db.update("users", values, "username=?", arrayOf(username))
    }
}
