package com.example.maths4l1fev1

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class HomeActivityViewModel @Inject constructor(): ViewModel() {

    val currentScore = MutableLiveData("")

    fun setCurrentScore(context: Context, username: String) {
        val dbHelper = DBHelper(context)
        currentScore.value = dbHelper.getScore(username)
    }

}