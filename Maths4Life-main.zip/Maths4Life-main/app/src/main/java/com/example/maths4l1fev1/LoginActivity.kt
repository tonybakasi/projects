package com.example.maths4l1fev1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.maths4l1fev1.databinding.ActivityLoginBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : AppCompatActivity() {

    private lateinit var mBinding: ActivityLoginBinding
    private lateinit var mDbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        mDbHelper = DBHelper(this)

        mBinding.btnsignin1.setOnClickListener {
            val user = mBinding.username1.text.toString()
            val pass = mBinding.password1.text.toString()

            if(user == "" || pass == "")
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
            else{
                val checkuserpass = mDbHelper.checkUsernamePassword(user, pass)
                if(checkuserpass){
                    Toast.makeText(this, "Sign in Complete", Toast.LENGTH_SHORT).show();
                    val intent = Intent (this, HomeActivity::class.java)
                    intent.putExtra("username", user);
                    startActivity(intent);
                }else{
                    Toast.makeText(this, "Wrong Credentials!", Toast.LENGTH_SHORT).show();
                }
            }

        }

    }
}