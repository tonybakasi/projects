package com.example.maths4l1fev1;

class Question(
    private var question: String = "",
    private var option1: String = "",
    private var option2: String = "",
    private var option3: String = "",
    private var answrNr: Int = 0
) {

    fun getQuestion() = question

    fun setQuestion(question: String) {
        this.question = question
    }

    fun getOption1() = option1

    fun setOption1(option1: String) {
        this.option1 = option1
    }

    fun getOption2() = option2

    fun setOption2(option2: String) {
        this.option2 = option2
    }

    fun getOption3() = option3

    fun setOption3(option3: String) {
        this.option3 = option3
    }

    fun getAnswrNr() = answrNr

    fun setAnswrNr(answrNr: Int) {
        this.answrNr = answrNr
    }
}
