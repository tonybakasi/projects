package com.example.maths4l1fev1

import androidx.multidex.MultiDexApplication
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Math4Life: MultiDexApplication()