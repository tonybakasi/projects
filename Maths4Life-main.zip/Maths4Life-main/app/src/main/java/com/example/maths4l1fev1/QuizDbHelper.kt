package com.example.maths4l1fev1;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns

class QuizDbHelper(context: Context): SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_VERSION = 1;
        const val DATABASE_NAME = "MathsQuiz.db"
    }

    private lateinit var db: SQLiteDatabase

    override fun onCreate(db: SQLiteDatabase) {
        this.db = db

        val SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                QuestionsTable.TABLE_NAME + " ( " +
                BaseColumns._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER " +
                ")";

        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();
    }

    override fun onUpgrade(db: SQLiteDatabase, p1: Int, p2: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    fun fillQuestionsTable() {

        val q1 = Question("How many digits are there in 5 million?", "5", "6", "100", 2)
        addQuestion(q1);
        val q2 = Question("2 tens + 0 ones =", "20", "1010", "200", 1)
        addQuestion(q2);
        val q3 = Question("How do you say the number 34 024?", "Thirty-four thousand a hundred and twenty three", "Three Thousand, four hundred and twenty-three ", "Thirty four thousand and twenty–three ", 3)
        addQuestion(q3);
        val q4 = Question("In 678 945 what is the value of 6?", "Ten Thousand", "Hundred Thousand", "Thousands", 2)
        addQuestion(q4);
        val q5 = Question("What does the three represent in 5834?", "30", "300", "3", 1)
        addQuestion(q5);
        val q6 = Question("In this number which digit is in the tens place? 98452", "9", "4", "5", 3)
        addQuestion(q6);
        val q7 = Question("Which number is the smallest?", "64", "61", "C66", 2)
        addQuestion(q7);
        val q8 = Question("What number is Two Hundred and forty-seven??", "200407", "2047", "247 ", 3)
        addQuestion(q8);
        val q9 = Question("Which is the largest number?", "761", "759", "777", 3)
        addQuestion(q9);
        val q10 = Question("Which numbers comes immediately before and after 79?", "78 and 80", "77 and 78", "80 and 81", 1)
        addQuestion(q10);
        val q11 = Question("How can we get the number six hundred and sixty-one?", "546+100+5", "334+200+127", "300+300+300", 2)
        addQuestion(q11);
        val q12 = Question("A square is a kind of…", "Rectangle", "Triangle", "Sphere", 1)
        addQuestion(q12);
        val q13 = Question("What is the same in an equilateral triangle?", "The same colour", "The same sides", "the same height", 2)
        addQuestion(q13);
        val q14 = Question("Between these three, what shape has the most corners?", "Square", "Circle", "Triangle", 1)
        addQuestion(q14);
        val q15 = Question("I am a shape that has five sides, what am I?", "Triangle", "Octagon", "Pentagon", 3)
        addQuestion(q15);
        val q16 = Question("How many grams are in 8kg?", "8000g", "800g", "80g", 1)
        addQuestion(q16);
        val q17 = Question("How many millimetres are there in 100cm?", "100 mm", "1000 mm", "10 mm", 2)
        addQuestion(q17);
        val q18 = Question("What is half a litre of milk equivalent to?", "400ml", "500ml", "300ml", 2)
        addQuestion(q18);
        val q19 = Question("Volume can be measured in …", "cm", "cm2", "cm3", 3)
        addQuestion(q19);
        val q20 = Question("Which of these is usually sold by the litre?", "Baked Beans", "Medicine", "Petrol", 3)
        addQuestion(q20);
        val q21 = Question("To find half of a number, you should divide it by …", "1", "2", "3", 2)
        addQuestion(q21);
        val q22 = Question("How do you find a quarter of a number?", "Divide it by 4", "Multiply it by 4", "Subtract 4", 1)
        addQuestion(q22);
        val q23 = Question("Which is greater: half of 10 or a quarter of 20?", "Half of 10", "Quarter of 20", "They are both the same", 3)
        addQuestion(q23);
        val q24 = Question("Two quarters is the same as …", "½", "¼", "2/8", 1)
        addQuestion(q24);
        val q25 = Question("2+17 =", "15", "19", "18", 2)
        addQuestion(q25);
        val q26 = Question("15–6=", "10", "9", "7", 2)
        addQuestion(q26);
        val q27 = Question("7 +...= 15", "6", "7", "8", 3)
        addQuestion(q27);
        val q28 = Question("10+10 =", "20", "10", "100", 1)
        addQuestion(q28);
        val q29 = Question("42-19 =", "18", "26", "23", 3)
        addQuestion(q29);
        val q30 = Question("13 + 0 =", "130", "13", "11", 2)
        addQuestion(q30);
        val q31 = Question("13 -...= 4", "9", "10", "8", 1)
        addQuestion(q31);
        val q32 = Question("26–21 =", "5", "6", "2", 1)
        addQuestion(q32);
        val q33 = Question("2 +...= 13", "15", "10", "9", 3)
        addQuestion(q33);
        val q34 = Question("11x3=", "30", "33", "36", 2)
        addQuestion(q34);
        val q35 = Question("12x12=", "24", "144", "1212", 2)
        addQuestion(q35);
        val q36 = Question("4x10=", "40", "14", "44", 1)
        addQuestion(q36);
        val q37 = Question("X x 8 = 72, What is X?", "10", "9", "8", 2)
        addQuestion(q37);
        val q38 = Question("15 divided by 5 is?", "5", "3", "1", 2)
        addQuestion(q38);
        val q39 = Question("What is 10 divided by 2?", "5", "6", "2", 1)
        addQuestion(q39);
        val q40 = Question("What is 12 divided by 4?", "8", "16", "4", 3)
        addQuestion(q40);
        val q41 = Question("Dividing means …", "Finding the total", "Shared in equal groups", "Numbers are bigger", 2)
        addQuestion(q41);
        val q42 = Question("What is 65 divided by 13?", "3", "4", "5", 3)
        addQuestion(q42);
    }

    fun addQuestion(question: Question) {
        val cv = ContentValues()
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswrNr());
        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    fun getAllQuestions(): MutableList<Question> {
        val questionList = mutableListOf<Question>()
        db = readableDatabase
        val c = db.rawQuery("SELECT *  FROM " + QuestionsTable.TABLE_NAME, null);

        if (c.moveToFirst()) {
            do {
                val question = Question();
                var index = c.getColumnIndex(QuestionsTable.COLUMN_QUESTION);
                if(index >= 0)
                     question.setQuestion(c.getString(index));

                index = c.getColumnIndex(QuestionsTable.COLUMN_OPTION1);
                if(index >= 0)
                    question.setOption1(c.getString(index));

                index = c.getColumnIndex(QuestionsTable.COLUMN_OPTION2);
                if(index >= 0)
                    question.setOption2(c.getString(index));

                index = c.getColumnIndex(QuestionsTable.COLUMN_OPTION3);
                if(index >= 0)
                    question.setOption3(c.getString(index));

                index = c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR);
                if(index >= 0)
                    question.setAnswrNr(c.getInt(index));
                questionList.add(question); // Add missing line for pushing the found question in questions list.
            } while (c.moveToNext());
        }
        c.close();
        return questionList;
    }
}
