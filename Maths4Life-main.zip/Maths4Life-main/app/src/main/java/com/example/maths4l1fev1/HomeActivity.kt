package com.example.maths4l1fev1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import com.example.maths4l1fev1.databinding.ActivityHomeBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HomeActivity : AppCompatActivity() {

    private lateinit var mBinding: ActivityHomeBinding
    private val mViewModel: HomeActivityViewModel by viewModels()
    private lateinit var mUsername: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        mUsername = intent.getStringExtra("username").toString()

        mViewModel.currentScore.observe(this) {
            mBinding.textViewHighscore.text = getString(R.string.high_score_0, it)
        }

        mBinding.buttonStartQuiz.setOnClickListener {
            val intent = Intent(this, QuizActivity::class.java)
            intent.putExtra("username", mUsername)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        mViewModel.setCurrentScore(this, username = mUsername)
    }
}