package com.example.maths4l1fev1

import android.app.ProgressDialog.show
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import com.example.maths4l1fev1.databinding.ActivityQuizBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class QuizActivity : AppCompatActivity() {

    private lateinit var mBinding: ActivityQuizBinding
    private val mViewModel: QuizActivityViewModel by viewModels()
    private lateinit var mUsername: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(mBinding.root)

        mViewModel.setQuestions(this)

        mUsername = intent.getStringExtra("username").toString()

        mViewModel.setOldHighScore(this, mUsername)

        /*
         * Observing GameState variable of viewModel
         */
        mViewModel.gameState.observe(this) { gameState ->
            if (gameState == QuizActivityViewModel.GameState.IDLE) { // if game state is IDLE
                mViewModel.moveToNextQuestion(); // this moves the currentQuestion variable in viewModel to first Question
                /*
                 * Setting GameState to STARTED, so it won't fallback to this "if condition",
                 * in order to not start from first question.
                 */
                mViewModel.gameState.postValue(QuizActivityViewModel.GameState.STARTED);
            }

            if (gameState == QuizActivityViewModel.GameState.OVER) { // if game state is OVER
                mViewModel.setNewHighScoreInDB(this, mUsername); // Setting New High Score In DB
                // Building Game Over Alert
                AlertDialog.Builder(this)
                    .setCancelable(false) // setting alert to non cancelable
                    .setTitle("Game Over") // setting title for alert
                    .setMessage(mViewModel.getGameOverMsg()) // Getting GameOverMessage From ViewModel
                    .setNegativeButton("Go Back") { dialogInterface, _ ->
                        dialogInterface.dismiss(); // dismissing the alert dialog on click of "go back" button
                        finish(); // also finishing current activity after dialog dismiss
                    }
                    .show(); // Displaying Alert For Game Over

            }
        }

        /*
         * observing Current Head index, and displaying in QuestionCountTextView
         */
        mViewModel.head.observe(this) { head ->
            mBinding.textViewQuestionCount.text = getString(
                R.string.question_1_12, head, QuizActivityViewModel.LAST_QUESTION_NUMBER
            )
        }

        /*
         * observing currentQuestion and displaying its fields in textViews on Screen.
         */
        mViewModel.currentQuestion.observe(this) { question ->
            mBinding.textViewQuestion.text = question.getQuestion(); // displaying question
            mBinding.radioButton1.text = question.getOption1(); // displaying option 1
            mBinding.radioButton2.text = question.getOption2(); // displaying option 2
            mBinding.radioButton3.text = question.getOption3(); // displaying option 3
        }

        /*
         * Observing current score, and displaying in score textView
         */
        mViewModel.currentScore.observe(this) { currentScore ->
            mBinding.textViewScore.text = getString(R.string.score_0, currentScore)
        }

        /*
         * Setting click listener on confirm button
         */
        mBinding.buttonConfirmNext.setOnClickListener {
            // Analyzing which option is selected.
            // 1, 2, 3 if any checked, -1 if no one was checked.
            val selected: Int = when {
                mBinding.radioButton1.isChecked -> 1
                mBinding.radioButton2.isChecked -> 2
                mBinding.radioButton3.isChecked -> 3
                else -> -1
            }

            // if no one was checked.
            if (selected < 0) {
                Toast.makeText(this, "Please select your answer.", Toast.LENGTH_SHORT).show();
            } else {
                // if any option was checked, passing that selected option number to viewModel
                // following function will check the answer
                // then it will update the currentScore
                // also it will set the newQuestion for display
                mViewModel.checkAnswerAndUpdateScoreThenMoveNext(selected);
            }

            // Clearing the selected radio buttons after a question has been answered.
            mBinding.radioGroup.clearCheck()
        }
    }
}