package lib;

/**
 * The Player has a name generated from their first name AND last name
 * @author tonyb
 *
 */

public class Player {
     /**
	 * The Player has a name AND a pair of dice.
	 */

	 //Fields
	    private Name name;
	    private Rollable pairOfDice;


	 //Constructors
	    /** This default constructor generates a new instance for the Player 
	     *  This is the initial default name with the initial date values.
	     **/
	    public Player() {
	        name = new Name();
	        pairOfDice = new PairOfDice();
}

	    /** This class generates a new instance of Player with given values.
	     * 
	     * */
	    public Player(Name name) {
	        this.name = name;
	        this.pairOfDice = new PairOfDice();
}

	    /** This class generates a new instance of Player with given values.
	     * 
	     *  @param is the player(s) name
	     *  @param the pair of dice
	     * */
	    public Player(Name name, Rollable pairOfDice) {
	        this.name = name;
	        this.pairOfDice = pairOfDice;
}


	  //Methods
	    
	    /**
	     * This code allows you to modify the player(s) name
	     * Does not return any value
	    */
	    public void setName(Name name) {
	        this.name = name;
}
	    /**
	     * This code allows you to retrieve the player(s) name
	       @return player name
	    */
	    public Name getName() {
	        return name;
}

	    /**
	     * This code generates a new instance for the pair of dice
	       @return pair of dice
	    */
	    public Rollable getRollable() {
	        return pairOfDice;
}

	    /**
	     * This code authorises the program to run and roll the dice
	     *
	     */
	    
	    public void rollDice() { pairOfDice.roll();}
	    
	    /**
	     * This code allows player to retrieve a randomly generated value for the pair of dice
	       @return pair of dice
	    */

	    public int getDiceScore() { return pairOfDice.getScore();}
	    
	    /**
	     * This code allows player to set and modify the Full player name
	     * @param fullPlayerName
	     */

	    public void setFullPlayerName(String fullPlayerName)
	    {
	        String[] splitName = fullPlayerName.split("\\s+");
	        name = new Name(splitName[0], splitName[1]);
}
	    
	    @Override
	    public String toString() {
	        return "Player:[name=" + name + ", pairOfDice=" + "[" + pairOfDice.toString() + "]]";
}

	    @Override
	    public boolean equals(Object obj) {
	        if (obj == null || this.getClass() != obj.getClass())
	            return false;

	        Player other = (Player) obj;

	        return this.name.equals(other.name)
	                && this.pairOfDice.equals(other.pairOfDice);
	    }
	    
	    

}
