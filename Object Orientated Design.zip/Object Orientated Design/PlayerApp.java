package main;

import java.util.ArrayList;

import lib.Player;

public class PlayerApp {
/**
 * A for-loop has been used to retrieve the full name of the player 
 * Once the player name is retrieved the "toLowerCase()" method
 * will return the player name to lower case
 * 
 */

	public static String execute(ArrayList<Player> players, String fullName) {
		players.get(0).setFullPlayerName(fullName);
		String res = "";
		for (int i = 0;i < players.size();i++) {
			Player player = players.get(i);
			if (player.getName().getFullName().contains("a")) {
				res = res + player.getName().getFirstName().toLowerCase() + ", " + player.getName().getFamilyName().toUpperCase() + "\n";
			}
		}
		return res;
	}
	
	
}
