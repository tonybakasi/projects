package lib;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Register implements Iterable<Name> {
	
	// Field
    private ArrayList<Name> NameList;

    // Constructor
    /** Generate empty Namelist. */
    
    public Register() {
        NameList = new ArrayList<>();
    }

    // Method(s)
    /* **
     * Below are common method(s) used in an aggregation class implementation
     **/

    /** Adds given name to the end of the Namelist.
     * 
     *@param name The Name to add. 
     *
     **/
    
    public void addName(Name name) {
        NameList.add(name);
    }
    
    /** 
     * Sorts the Namelist in ascending order
     * 
     **/
    
    public void sortRegister() {
        Collections.sort(NameList);
    }
    
    /** 
     * Allows user to go through collection
     * returns elements in the NameList one by one
     * 
     **/
    
    public Iterator<Name> iterator(){
    	return NameList.iterator();
    }

    /** Returns name at index i.
     * 
     * @param i The index to be searched for.
     * 
     * @return The name at index i.
     * 
     * */
    public Name getName(int i) {
        return NameList.get(i);
    }

    /** Remove name at index i.
     * 
     * @param i The index to be removed.
     * 
     * @return The name at index i.
     * 
     * */
    public Name removeName(int i) {
        return NameList.remove(i);
    }

    /** Checks if Namelist is empty.
     * 
     * @return either true/false, banking on whether the Namelist is empty or not. 
     * 
     * */
    public boolean isRegisterEmpty() {
        return NameList.isEmpty();
    }

    /** Returns number of name(s) in the Namelist.
     * 
     * @return Number of name(s) in the Namelist.
     * 
     * */
    public int registerSize() {
        return NameList.size();
    }

    /** Clears any names in the Namelist.*/
    public void clearRegister() {
        NameList.clear();
    }

    /** Searches for required family name in the name list, returns either. true or false
     *
     * @param familyName The family name to be searched for.
     * 
     * @return true or false depending on whether the family name exists in the Namelist.
     *
     */
    public boolean searchRegisterByFamilyName(String familyName) {
        return NameList.stream().anyMatch(s->s.getFamilyName().equals(familyName));
    }

    /**Counts the amount times a first name pops up with a character included.
     *
     * @param 'e' is the character that will be tested.
     * first names with the character 'e' will be counted.
     * 
     * @return first names that end with character 'e' included.
     *
     * will return true if 'e' is included, will return false if not
     * 
     */
    public int countFirstNameOccurrences(char e) {
        //using for-each loop
    	/*int count = 0;

    	for (Name name : NameList) {
    		if (name.getFirstName().charAt(name.getFirstName().length()-1) == e) {
    			count++;
    		}
    	}

    	return count;*/

        //using Java 8 streams
        return (int) NameList.stream().filter(s -> s.getFirstName().charAt(s.getFirstName().length()-1) == e).count();
    }

    /** Will return a string that contains the Namelist name data. 
     * */
    @Override
    public String toString() {
        String str = "Register:[";
        boolean fg = false;
        for(Name name: NameList)
        {
            if (fg) str += ", ";
            fg = true;
            str += name.toString();
        }
        str = str + "]";
        return str;
    }
}
