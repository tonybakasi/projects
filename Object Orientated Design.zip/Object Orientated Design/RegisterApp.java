package main;

import lib.Name;
import lib.Register;

public class RegisterApp {

	/**
	 * A for-loop has been used to retrieve the full name of the register 
	 * Once the register name is retrieved the "toLowerCase()" method
	 * will return the register name to lower case
	 * 
	 */

    public static String execute(Register reg, Name n)
    {
        String output = "";
        reg.removeName(1);
        reg.addName(n);
        for (int i = 0; i < reg.registerSize(); i++) {
            if(reg.getName(i).getFamilyName().length() >= 5){
                output += reg.getName(i).getFamilyName().toUpperCase() +", " + reg.getName(i).getFirstName().charAt(0) + "\n";
            }
        }
        return output;
    }
}